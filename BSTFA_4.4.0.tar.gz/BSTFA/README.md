# BSTFA
Bayesian Spatiotemporal Factor Analysis
